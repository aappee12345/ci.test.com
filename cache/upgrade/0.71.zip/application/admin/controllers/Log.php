<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*
class FIRST_Controller extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('adminnavmodel','adminnav',TRUE);
	}

	public function admininit()
	{
		
		$res = $this->adminnav->check();
		return $res;
	}
	
}
*/
class Log extends Homebase
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('usersessionmodel','usersession',TRUE);
		$this->load->model('logmodel','logs',TRUE);

	}
	//日志列表页面
	public function index()
	{
		$header['title'] = "日志列表";
		$header['keywords'] = "日志列表";
		//$data['adminmenulist'] = $this->admininit();
		//判断登录及权限
		$arr['ma_lastloginip'] = (String)ip2long($_SERVER['REMOTE_ADDR']);
		$header['user'] = $this->usersession->check($arr,'13');
		$header['n_name'] = $this->n_name['n_name'];
		$data['act'] = 'log';
		$this->load->view('public/header',$header);
		$this->load->view('public/top');
		$this->load->view('public/left',$data);
		unset($data['act']);
		//获取日志
		//分页
		$condition['keys'] = isset($_POST['keys'])?$_POST['keys']:'';
		$this->load->library('pagination');
		$perPage = 10;
		$config['base_url'] = site_url('log/index');
		$config['total_rows'] = $this->db->like('l_operator', $condition['keys'], 'both')->or_like('l_case', $condition['keys'], 'both')->count_all_results('log');
		$config['per_page'] = $perPage;
		$config['uri_segment'] = 3;

		$this->pagination->initialize($config);
		$data['links'] = $this->pagination->create_links();
		
		$offset = $this->uri->segment(3);
		$this->db->limit($perPage,$offset);
		
		$data['logs'] = $this->logs->check($condition);
		unset($data['logs']['keys']);
		$data['totals'] = $config['total_rows'];
		$data['per'] = $config['per_page'];
		$data['keys'] = $condition['keys'];
		$this->load->view('log/index',$data);
		$this->load->view('public/footer');
	}

	//日志删除
	public function delLog()
	{
		//判断登录及权限
		$arr['ma_lastloginip'] = (String)ip2long($_SERVER['REMOTE_ADDR']);
		$header['user'] = $this->usersession->check($arr,'12');
		
		$lid = $this->uri->segment(3);
		$res = $this->logs->del($lid);
		if ($res)
		{
			echo "<script>alert('删除日志成功！');window.location.href='".site_url('log/index')."'</script>";
		}
		else
		{
			echo "<script>alert('删除日志失败！');window.location.href='".site_url('log/index')."'</script>";
		}
	}

	//删除选中
	public function delLogBatch()
	{
		//判断登录及权限
		$arr['ma_lastloginip'] = (String)ip2long($_SERVER['REMOTE_ADDR']);
		$header['user'] = $this->usersession->check($arr,'12');
		//获取ID数组
		//$ids = $_POST['IDCheck'];
		$ids = $this->input->post('IDCheck');
		$days = $this->input->post('days');
		if ($ids==null&&!isset($days))
		{
			echo "<script>alert('请在要删除的日志记录前的方框内打勾或选择日志所处的时间段！');window.history.go(-1);</script>";
			exit;
		}
		
		if (isset($ids))
		{
			foreach ($ids as $value)
			{
				$this->logs->del($value);
			}
		}
		elseif (isset($days))
		{
			//计算时间
			$thattime = time()-$days*24*3600;
		
			$this->db->delete('log',array('updated_at <'=>$thattime));
		}
		
		echo "<script>window.location.href='".site_url('log/index')."'</script>";
	}
}