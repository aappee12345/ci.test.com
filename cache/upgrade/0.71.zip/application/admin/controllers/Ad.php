<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*
class FIRST_Controller extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('adminnavmodel','adminnav',TRUE);

	}

	public function admininit()
	{
		
		$res = $this->adminnav->check();
		return $res;
	}
	
}
*/
class Ad extends Homebase
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('usersessionmodel','usersession',TRUE);
		$this->load->model('logmodel','logs',TRUE);
		$this->load->model('admodel','ad',TRUE);
	}

	//广告位列表
	public function index()
	{
		$header['title'] = "广告位管理";
		$header['keywords'] = "广告位管理";
		//判断登录及权限
		$arr['ma_lastloginip'] = (String)ip2long($_SERVER['REMOTE_ADDR']);
		$header['user'] = $this->usersession->check($arr,'41');

		$header['n_name'] = $this->n_name['n_name']; 
		$this->load->view('public/header',$header);
		$this->load->view('public/top');

		//$data['adminmenulist'] = $this->admininit();
		$data['act'] = 'adlist';
		$this->load->view('public/left',$data);
        unset($data['act']);
		$data['adlist'] = $this->ad->check();
		$data['count'] = count($data['adlist']);
		$this->load->view('ad/index',$data);
		$this->load->view('public/footer');

	}

	//广告位添加
	public function add()
	{
		$header['title'] = "广告位添加";
		$header['keywords'] = "广告位添加";
		//判断登录及权限
		$arr['ma_lastloginip'] = (String)ip2long($_SERVER['REMOTE_ADDR']);
		$header['user'] = $this->usersession->check($arr,'42');
		$header['n_name'] = $this->n_name['n_name']; 
		$this->load->view('public/header',$header);
		$this->load->view('public/top');
		//$data['adminmenulist'] = $this->admininit();
		$data['act'] = 'addad';
		$this->load->view('public/left',$data);
		unset($data['act']);
		if (IS_POST)
		{
			$this->load->library('form_validation');
			$status = $this->form_validation->run('ad');
			$res = false;
			if ($status)
			{
				//验证通过
				$res = $this->ad->insert_ad();
			}

			if ($res!==false)
			{
				$username = $header['user']['ma_username'];
				$this->logs->addLog('添加广告位成功！',$username);
				echo "<script>alert('添加广告位成功！');window.location.href='".site_url('Ad/index/')."'</script>";
				exit;
			}
		}
				
		$this->load->view('ad/add');
		$this->load->view('public/footer');
	}

	//广告位修改
	public function update()
	{
		$header['title'] = "广告位修改";
		$header['keywords'] = "广告位修改";
		//判断登录及权限
		$arr['ma_lastloginip'] = (String)ip2long($_SERVER['REMOTE_ADDR']);
		$header['user'] = $this->usersession->check($arr,'43');
		$header['n_name'] = $this->n_name['n_name']; 
		$this->load->view('public/header',$header);
		$this->load->view('public/top');
		//$data['adminmenulist'] = $this->admininit();
		$data['act'] = 'updatead';
		$this->load->view('public/left',$data);
		unset($data['act']);

		if (IS_POST)
		{
			$this->load->library('form_validation');
			$status = $this->form_validation->run('ad');
			$res = false;
			if ($status)
			{
				//验证通过
				$id = $this->input->post('ad_id');
				$res = $this->ad->update_ad($id);
			}

			if ($res!==false)
			{
				$username = $header['user']['ma_username'];
				$this->logs->addLog('修改广告位成功！',$username,$id);
				echo "<script>alert('修改广告位成功！');window.location.href='".site_url('Ad/index/')."'</script>";
				exit;
			}
		}
		$id = $this->uri->segment(3);
		$data['ad'] = $this->ad->find_ad($id);
		$this->load->view('ad/update',$data);
		$this->load->view('public/footer');
	}


	//广告位删除
	public function delAd()
	{
		//判断登录及权限
		$arr['ma_lastloginip'] = (String)ip2long($_SERVER['REMOTE_ADDR']);
		$header['user'] = $this->usersession->check($arr,'44');
		$header['n_name'] = $this->n_name['n_name']; 
		$id = $this->uri->segment(3);
		//判断当前广告位下是否存在广告
		$guanggao = $this->db->where(array('g_ad_id'=>$id))->get('guanggao')->row_array();
		if ($guanggao)
		{
			echo "<script>alert('该广告位下存在广告，请先删除广告！');window.location.href='".site_url('guanggao/index/'.$id)."'</script>";
			exit;
		}
		$res = $this->ad->doDel($id);
		if ($res)
		{
			$username = $header['user']['ma_username'];
			$this->logs->addLog('删除广告位成功！',$username,$id);
			echo "<script>alert('删除广告位成功！');window.location.href='".site_url('Ad/index/')."'</script>";
			exit;
		}
		else
		{
			echo "<script>alert('删除广告位失败！');window.location.href='".site_url('Ad/index/')."'</script>";
			exit;
		}
	}

	/**
	  * 批量删除广告位
      */
	public function batchDelAd()
	{
		//判断登录及权限
		$arr['ma_lastloginip'] = (String)ip2long($_SERVER['REMOTE_ADDR']);
		$header['user'] = $this->usersession->check($arr,'44');
		$CheckIDs = $this->input->post('IDCheck');
		if ($CheckIDs==null)
		{
			echo "<script>alert('请在要删除的广告位前的方框内打勾！');window.history.go(-1);</script>";
			exit;
		}
		$flag = false;
		foreach ($CheckIDs as $value)
		{
			$status = $this->ad->doDel($value);
			if ($status&&($flag===false))
			{
				$flag = true;
			}
		}
		//删除成功
		if ($flag===true)
		{
			$this->logs->addLog('批量删除广告位成功！',$username,implode(',', $CheckIDs));
			echo "<script>alert('批量删除广告位成功！');window.location.href='".site_url('ad/index')."'</script>";
			exit;
		}
		else
		{
			echo "<script>alert('批量删除广告位失败！');window.location.href='".site_url('ad/index')."'</script>";
			exit;
		}
		
	}

	/*ajax修改排序*/
	public function ajaxsort()
	{
		if (IS_AJAX)
		{
			$arr['ad_id'] = $this->input->post('id');
			$arr['ad_sort'] = $this->input->post('sort');
			//查询当前选择分类的子分类
			$res = $this->ad->ajaxupdate_sort($arr);
			if ($res)
			{
				echo json_encode($res);
			}
			else
			{
				echo json_encode($res);
			}
			
		}
	}
}