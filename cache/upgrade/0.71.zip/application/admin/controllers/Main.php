<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*
class FIRST_Controller extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('adminnavmodel','adminnav',TRUE);

	}

	public function admininit()
	{
		
		$res = $this->adminnav->check();
		return $res;
	}
	
}
*/

class Main extends Homebase {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('usersessionmodel','usersession',TRUE);
	}

	public function index()
	{
		
		$header['title'] = "欢迎来到后台管理";
		$header['keywords'] = "欢迎来到后台管理";
		$arr['ma_lastloginip'] = (String)ip2long($_SERVER['REMOTE_ADDR']);
		$header['user'] = $this->usersession->check($arr,10);
		$header['n_name'] = $this->n_name['n_name'];
		$manager = $this->db->where(array('ma_username'=>$header['user']['ma_username']))->get('manager')->row_array();
		$data['role'] = $this->db->where(array('r_id'=>$manager['ma_rid']))->get('role')->row_array();
		//今天零点时间戳
		$time1 = strtotime(date('Y-m-d',time()).' 00:00:00');
		//查询当天发表文章数
		$data['count1'] = count($this->db->where('updated_at >',$time1)->get('article')->result_array());
		//本周一零点时间戳
		$time2=mktime(0,0,0,date('m'),date('d')-date('w')+1,date('Y'));
		$data['count2'] = count($this->db->where('updated_at >',$time2)->get('article')->result_array());
		$data['count3'] = count($this->db->where('updated_at 	>',0)->get('article')->result_array());
		//$data['adminmenulist'] = $this->admininit();
		$this->load->view('public/header',$header);
		$this->load->view('public/top');
		$this->load->view('public/left',$data);
		$this->load->view('main/index');
		$this->load->view('public/footer');
	}
}