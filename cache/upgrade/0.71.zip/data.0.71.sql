-- ----------------------------
-- Table structure for `mr_test`
-- ----------------------------
DROP TABLE IF EXISTS `mr_test`;
CREATE TABLE `mr_test` (
  `id` tinyint(2) unsigned NOT NULL AUTO_INCREMENT COMMENT 'sdf',
  `name` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of mr_test
-- ----------------------------
INSERT INTO `mr_test` VALUES ('1', 'sdfd');
INSERT INTO `mr_test` VALUES ('2', 'dsf');

