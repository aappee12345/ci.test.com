/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : wantong

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2017-08-14 17:06:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `mr_test`
-- ----------------------------
DROP TABLE IF EXISTS `mr_test`;
CREATE TABLE `mr_test` (
  `id` tinyint(2) unsigned NOT NULL AUTO_INCREMENT COMMENT 'sdf',
  `name` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of mr_test
-- ----------------------------
INSERT INTO `mr_test` VALUES ('1', 'sdfd');
INSERT INTO `mr_test` VALUES ('2', 'dsf');
